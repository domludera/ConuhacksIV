require('@google-cloud/debug-agent').start({ allowExpressions: true });
var functions = require('firebase-functions');
var csv = require('csv-parser')
var fs = require('fs')

function isPointInRect( pointLat, pointLon, topleftLat, topleftLon, bottomRightLat, bottomRightLon) {

   return (topleftLon < parseFloat(pointLon)
          && topleftLat > parseFloat(pointLat)
          && bottomRightLon > parseFloat(pointLon)
                 && bottomRightLat < parseFloat(pointLat))
 }

 function getDistanceFromLatLonInKm(lat1,lon1,lat2,lon2) {
  var R = 6371; // Radius of the earth in km
  var dLat = deg2rad(lat2-lat1);  // deg2rad below
  var dLon = deg2rad(lon2-lon1);
  var a =
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLon/2) * Math.sin(dLon/2)
    ;
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  var d = R * c; // Distance in km
  return d;
}

function deg2rad(deg) {
  return deg * (Math.PI/180)
}

function doesSectorsContain(sectors, sector){
  var sectorArray = sectors.split(";");
  //console.log(sectorArray);
  //console.log(data.sector);
  return (sectorArray.includes(sector));
}


var Transform = require('stream').Transform;
var util = require('util');
var sort = require('sort-stream')

function Filter(filterProps, options) {
  // allow use without new
  if (!(this instanceof Filter)) {
    return new Filter(filterProps, options);
  }

  // init Transform
  if (!options) options = {}; // ensure object
  options.objectMode = true; // forcing object mode
  Transform.call(this, options);
  this.filterProps = filterProps;
}
util.inherits(Filter, Transform);

exports.services3 = functions.https.onRequest((request, response) => {
  console.log("method:" + request.method);
  console.log(request.headers);
  console.log(request.query);
  console.log("body:" + request.body);

  if (request.method === "POST"){
    var search = JSON.parse(request.body);
      console.log(search);

      var fundedGroupParser = new Transform({objectMode: true});
      fundedGroupParser._transform = function(data, encoding, done) {
        //console.log(data);
        var service = {name:"", latitude:0, longitude:0, distance:0, sector:"",
                       city:"", province:"", provinceCode:"",postCode:"",
                       minorityPopNumber:0, minorityPopPercentage:0};
        service.name = data.org;
        service.latitude = data.latitude;
        service.longitude = data.longitude;
        service.sector = data.sectorEnglish;
        service.province = data.provinceNameEnglish;
        service.postCode = data.postalCode;
        service.provinceCode = "pr" + data.provinceCode;
        service.city = data.city;
        service.distance = 0;
        service.minorityPopNumber = data.localMinorityPopNumber;
        service.minorityPopPercentage = data.localMinorityPopPercentage;
        //console.log(service);
        this.push(service);
        done();
      };

      var iSchoolParser = new Transform({objectMode: true});
      iSchoolParser._transform = function(data, encoding, done) {
        //console.log(data);
        var service = {name:"", latitude:0, longitude:0, distance:0, sector:"",
        city:"", province:"", provinceCode:"",postCode:"",
        minorityPopNumber:0, minorityPopPercentage:0};
        service.name = data.name;
        service.latitude = data.latitude;
        service.longitude = data.longitude;
        service.sector = "00 IS";
        service.postCode ="";
        service.provinceCode = data.provinceCode;
        service.province = data.provinceNameEn;
        service.city = data.censusSubdivisionName;
        service.distance = 0;
        service.minorityPopNumber = data.localMinorityPopNumber;
        service.minorityPopPercentage = data.localMinorityPopPercentage;

        //console.log(service);
        this.push(service);
        done();
      };

      var mSchoolParser = new Transform({objectMode: true});
      mSchoolParser._transform = function(data, encoding, done) {
        //console.log(data);
        var service = {name:"", latitude:0, longitude:0, distance:0, sector:"",
        city:"", province:"", provinceCode:"",postCode:"",
        minorityPopNumber:0, minorityPopPercentage:0};
        service.name = data.name;
        service.latitude = data.latitude;
        service.longitude = data.longitude;
        service.sector = "00 MS";
        service.postCode ="";
        service.provinceCode = data.provinceCode;
        service.province = data.provinceNameEn;
        service.city = data.censusSubdivisionName;
        service.distance = 0;
        service.minorityPopNumber = data.localMinorityPopNumber;
        service.minorityPopPercentage = data.localMinorityPopPercentage;

        //console.log(service);
        this.push(service);
        done();
      };

      var provinceCodeFilter = new Filter(search, {objectMode: true});
      provinceCodeFilter._transform = function(data, encoding, done) {
        //console.log("provinceCodeFilter called");
        //console.log(data);
        if ((this.filterProps.provincecode.startsWith("!") && this.filterProps.provincecode.substring(1) !== data.provinceCode)
            || (!this.filterProps.provincecode.startsWith("!") &&
            data.provinceCode === this.filterProps.provincecode)){
              this.push(data);
              //console.log(data);
        }
        done();
      };

      var geoRectFilter = new Filter(search, {objectMode: true});
      geoRectFilter._transform = function(data, encoding, done) {
        //console.log("geoRectFilter called");
        //console.log(data);
        //console.log(this.filterProps);
        if (isPointInRect(data.latitude, data.longitude,
                          this.filterProps.regionrect.tllat, this.filterProps.regionrect.tllon,
                          this.filterProps.regionrect.brlat, this.filterProps.regionrect.brlon)){
        //  console.log(data);
          var centerLatitude = (this.filterProps.regionrect.tllat + this.filterProps.regionrect.brlat) / 2;
          var centerLongitude = (this.filterProps.regionrect.tllon + this.filterProps.regionrect.brlon) / 2;
          data.distance = getDistanceFromLatLonInKm(centerLatitude, centerLongitude,
                                                    data.latitude, data.longitude)
          this.push(data);
        }
        done();
      };
      var sectorFilter = new Filter(search, {objectMode: true});
      sectorFilter._transform = function(data, encoding, done) {
        //console.log("sectorFilter called");
        //console.log(this.filterProps.sector);
        //console.log(data.sector);
        var sectorArray = this.filterProps.sectors.split(";");
        //console.log(sectorArray);
        //console.log(data.sector);
        if (doesSectorsContain(this.filterProps.sectors, data.sector)){
          this.push(data);
        }
        done();
      };

    let chunks = [];
    var mSchoolStream;
    var iSchoolStream;
    var fundedGroupStream;
    var CombinedStream = require('combined-stream');
    var combinedStream = CombinedStream.create();

    //append funded group stream
    fundedGroupStream = fs.createReadStream('funded_groups_v02.csv');
    console.log('funded_groups_v02.csv is used');

    combinedStream.append(fundedGroupStream.pipe(csv())
                                           .pipe(fundedGroupParser));

    //append school  streams
    iSchoolStream = fs.createReadStream('immersion_schools_v02.csv');
    iSchoolStream.setEncoding('utf8');
    console.log('immersion_schools_v02.csv is used');
    combinedStream.append(iSchoolStream.pipe(csv())
                                      .pipe(iSchoolParser));
    //
    mSchoolStream = fs.createReadStream('minority_schools_v02.csv');
    mSchoolStream.setEncoding('utf8');
    console.log('minority_schools_v02.csv is used');
    combinedStream.append(mSchoolStream.pipe(csv())
                                      .pipe(mSchoolParser));

    combinedStream
      .pipe(provinceCodeFilter)
      .pipe(geoRectFilter)
      .pipe(sectorFilter)
      .pipe(sort(function (a, b) {
        if (a.distance > b.distance){
          return 1;
        }else if (a.distance < b.distance){
          return -1;
        }else{
          return 0;
        }
      }))
      .on('data', function (record) {
          //console.log(record);
        //  response.send(record);
          chunks.push(record);
      })
      .on('end', function() {
        //console.log(chunks);
        response.send(chunks);

      });
   }
});
