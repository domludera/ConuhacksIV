import React from 'react';
import { Provider } from 'react-redux'
import configStore from './Redux/store'
import { AppRegistry,
    ActivityIndicator,
    StyleSheet,
    Text,
    View } from 'react-native';
import TestStore from './testStore';

class TestApi extends React.Component {
  render(){
    return(
      <Provider store={ configStore() }>
      <TestStore />
      </Provider>
  );
  }
}

AppRegistry.registerComponent('ODGMobile', () => TestApi);
