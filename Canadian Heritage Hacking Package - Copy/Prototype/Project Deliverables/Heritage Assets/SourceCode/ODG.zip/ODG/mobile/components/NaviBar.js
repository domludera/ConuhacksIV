import React, { Component } from 'react'
import {
  Modal,
  View,
  Image,
  Switch,
  StatusBar,
  StyleSheet,
  TouchableHighlight,
    Platform,
  Dimensions
} from 'react-native'
import { connect } from 'react-redux';
import RadioForm, {RadioButton, RadioButtonInput, RadioButtonLabel} from 'react-native-simple-radio-button'
import { Container, Button, Content, Header, Title, List, ListItem, Text, Radio, Icon, Left, Right, Body} from 'native-base';
const { width, height } = Dimensions.get('window')
import * as FiltersActionCreators from '../reducers/FiltersActionCreators'
import I18n from 'react-native-i18n'
import LocationModal from './Search/LocationModal';
import FilterModal from './Filters/';
import LocationSearchInfo from './Search/LocationSearchInfo';
const DEVICE_WIDTH = Dimensions.get(`window`).width;
const styles = StyleSheet.create({
    background: {
      backgroundColor:'#335075',
        color:'#335075'
    }});
class NaviBar extends Component {


  getSectorsCount(sectors)  {
    var sectorsArray = sectors.split(";").filter(function(word){
      return (word != "");
    })
    return  sectorsArray.length.toString();
  };
  constructor(props) {
    super(props);

  };

    render() {
      let {naviProps, filters } = this.props;
      return (
      <View style={{backgroundColor: '#335075'}}>
        <Header style={{display:'flex', justifyContent: 'flex-start', flexDirection:'row', borderBottomWidth: 0, backgroundColor: '#335075'}}>
           <Left style={{flex:0}}>
             <Button light
             onPress={ () => naviProps.navigation.navigate('DrawerOpen')}
             transparent>
                 <Icon name='menu' />
             </Button>
         </Left>
         <Body style={{flex:0, backgroundColor:'#4b6483'}}>
          <Button light block onPress={ () => {

            this.searchModal.getWrappedInstance()._setModalVisible(true)
          }}
          style={{height: 35, minWidth: DEVICE_WIDTH / 2, backgroundColor:'#4b6483'}}
          >
          <LocationSearchInfo/>
          </Button>
         </Body>
         <Right style={{flex:1, paddingLeft: (Platform.OS == 'ios') ? 20 : 5, justifyContent: 'center'}}>
             <Button transparent style={{ borderColor: '#fdd767', borderWidth: 1, borderRadius: 4, height: 30}} onPress={ () => this.child.getWrappedInstance()._setModalVisible(true)}>
             <Text style={{fontSize: 12, color: 'white', paddingVertical: 4}}>{I18n.t('main.navibar.filters') + "(" + this.getSectorsCount(this.props.filters.sectors) + ")"}</Text>
             </Button>
         </Right>
        </Header>

        <LocationModal ref={instance => { this.searchModal = instance; }}  />
        <FilterModal ref={instance => { this.child = instance; }}/>
        </View>
          )
    }

}
const mapStateToProps = (state) => ({
    filters: state.Filters
  });

  export default connect(
      mapStateToProps,
      null,null,
      { withRef: true }
  )(NaviBar);
