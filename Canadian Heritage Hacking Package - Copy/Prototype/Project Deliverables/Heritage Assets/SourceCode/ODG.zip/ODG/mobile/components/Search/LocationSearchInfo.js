import { connect } from 'react-redux';

import React, { Component } from 'react'
import {
  Modal,
  View,
  Image,
  Switch,
  StatusBar,
  TouchableHighlight,
  PropTypes,
  Dimensions
} from 'react-native'
import {Text} from 'native-base';
import I18n from 'react-native-i18n'
import * as PlaceSearchActionCreators from '../../reducers/PlaceSearchActionCreators';


class LocationSearchInfo extends React.Component {

  // shouldComponentUpdate(nextProps) {
  //   return !(this.props.placeSearch.placeSearchInvoked);
  // }
  _resetSearchedStatus() {
    let { dispatch } = this.props;
    let action = PlaceSearchActionCreators.stopUntilNextSearch();
    dispatch(action);
  }

  render() {
    const { placeSearch } = this.props;
    console.log("location search info", this.props.placeSearch);

    return (
      <View style={{backgroundColor:'#4b6483'}}>
      <Text style={{color:'white'}}>{I18n.t('main.navibar.pressToSearch')}</Text>
      </View>
    );
  }
}

const mapStateToProps = (state) => ({
    placeSearch: state.PlaceSearch,
    modalShouldClose: state.PlaceSearch.modalShouldClose,
    filters: state.Filters,
    error: state.Services.error,
    loading: state.Services.loading,
});

export default connect(
    mapStateToProps,
)(LocationSearchInfo);
