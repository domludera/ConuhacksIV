import React from 'react'
import {
  StyleSheet,
  TouchableHighlight,
  Text,
  View,
  Alert,
  AppState,
  Image,
  Dimensions,
  Platform,
} from 'react-native'
import Swiper from 'react-native-swiper'
import Permissions from 'react-native-permissions';
import { Container, Content, List, ListItem, Button} from 'native-base';
import CheckBox from 'react-native-checkbox';
import { Col, Row, Grid } from 'react-native-easy-grid';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as FiltersActionCreators from '../../reducers/FiltersActionCreators';
import I18n from 'react-native-i18n'

const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;

var styles = {
  wrapper: {
  },
  slide: {
    flex: 1,
    flexDirection: 'column',
    backgroundColor: '#FFFFFF'
  },
  slideTitle: {
    color: '#F27242',
    fontFamily: 'Roboto',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    fontSize: 34,
    marginTop:55,
    marginBottom:17,
    marginLeft:35,
    marginRight:20,
    minHeight: 42,
    flexWrap: 'wrap',
    flex:-1
  },
  slideText: {
    color: '#335075',
    fontFamily: 'Roboto',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    marginTop: 10,
    marginBottom: 10,
    marginHorizontal: 35,
    fontSize: 16,
    lineHeight: 28,
    flex: -1
  },

  slide1Image:{
    zIndex: -1,
    flex: 1,
    marginBottom: 10,
    marginLeft: 1,
    marginRight: 1,
    position: 'relative',
    left: 0,
    top: 0,
    resizeMode: 'contain',
    height: 44,
    width: 100,
    marginHorizontal: 0,
    paddingHorizontal: 0,

    //height:windowHeight,
  },


  slide2Row: {
    color: '#335075',
    marginLeft:35,
    marginRight:20,
    marginTop:10,
  },
  slide2RowText: {
    color: '#335075',
    fontSize: 20,
  },

  slide3ButtonGroup: {
        flex:1,
    alignItems: 'center',
    flexDirection: 'column',
    justifyContent: 'center',
  },
  slide3Button: {

    backgroundColor: '#F27242',
    marginBottom:10,
    marginLeft:35,
    marginRight:35,
    borderRadius: 8,
    flex: 0,
    height: 60,
  },
  slide3ButtonText: {
    fontSize: 18,
    lineHeight: 21,
    color:'#FFFFFF',
  }
}

class WalkThrough extends React.Component {
  state = {
    types: [],
    status: {},
  }
  static navigationOptions = {
    title: ' ',header: null
  };
  componentWillMount(){
    this.props.filters.sectors = "";
  }
  componentDidMount() {
    let types = Permissions.getPermissionTypes()
    this.setState({ types })
    this._updatePermissions(types)
    AppState.addEventListener('change', this._handleAppStateChange.bind(this));
  }

  componentWillUnmount() {
    AppState.removeEventListener('change', this._handleAppStateChange.bind(this));
  }

  //update permissions when app comes back from settings
  _handleAppStateChange(appState) {
    if (appState == 'active') {
      this._updatePermissions(this.state.types)
    }
  }
  _deleteSchoolSectors()  {
    this._deleteSector("00 MS");
    this._deleteSector("00 IS");

  };
  _addSchoolSectors()  {
    this._addSector("00 MS");
    this._addSector("00 IS");
  }
  _includeSchoolSectors(sectors)  {
    return sectors.includes("00 MS") || sectors.includes("00 IS");
  }
  _deleteSector(sector)  {

    let { dispatch, filters } = this.props;
    filters.sectors = filters.sectors.replace(";"+sector , "") ;
    filters.sectors = filters.sectors.replace(sector + ";", "") ;
    filters.sectors = filters.sectors.replace(sector, "") ;
    let action = FiltersActionCreators.update(filters)
    dispatch(action)
  };
  _addSector(sector)  {

    let { dispatch, filters } = this.props;
    filters.sectors += ";";
    filters.sectors += sector;
    var lastString = filters.sectors.substr(0, 1)
    if (lastString === ";"){
      filters.sectors = filters.sectors.substr(1, filters.sectors.length - 1)
    }
    let action = FiltersActionCreators.update(filters)
    dispatch(action)
  };
  _onLanguageButtonPress (language)  {
    let { dispatch, filters } = this.props;
    filters.language = language;
    if (language === "en"){
      filters.provinceCode = "pr24";
    }else{
      filters.provinceCode = "!pr24";
    }
    let action = FiltersActionCreators.update(filters)
    dispatch(action);
    const location = 'location'
    if (this.state.status[location] != 'authorized'){
      this._requestPermission(location);
    }
    this.props.navigation.navigate('Home');
  };
  _openSettings() {
    return Permissions.openSettings()
      .then(() => alert('back to app!!'))
  }

  _updatePermissions(types) {
    Permissions.checkMultiplePermissions(types)
      .then(status => {
        if (this.state.isAlways) {
          return Permissions.getPermissionStatus('location', 'always')
            .then(location => ({...status, location}))
        }
        return status
      })
      .then(status => this.setState({ status }))
  }

  _requestPermission(permission) {
    var options

    if (permission == 'location') {
      options = this.state.isAlways ? 'always' : 'whenInUse'
    }

    Permissions.requestPermission(permission, options)
      .then(res => {
        this.setState({
          status: {...this.state.status, [permission]: res}
        })
        if (res != 'authorized') {
          Alert.alert(
            'Whoops!',
            "There was a problem getting your permission. Please enable it from settings.",
            [
              {text: 'Cancel', style: 'cancel'},
              {text: 'Open Settings', onPress: this._openSettings.bind(this) },
            ]
          )
        }
      })
      .catch(e => console.warn(e))
      .then(() => this._updatePermissions(this.state.types))
  }
  render () {
    const {language} = this.props
    return (
      <Swiper style={styles.wrapper} loop={false}
      activeDot={<View style={{backgroundColor: '#FF9800', width: 8, height: 8, borderRadius: 4, marginLeft: 3, marginRight: 3, marginTop: 3, marginBottom: 3}} />}
      >
      <View style={styles.slide}>

        <Text style={styles.slideTitle}>{I18n.t('intros.intro1Title')}</Text>
        <Text style={styles.slideText}>{I18n.t('intros.intro1')}</Text>
        <Image style ={{
            width: windowWidth,
            height: windowWidth / 2
          }}
          source={require('./intro.gif')}
        />

      </View>
      <View style={styles.slide}>
      <Text style={styles.slideTitle}>{I18n.t('intros.intro2Title')}</Text>
      <Container>
                      <Content >
                      <Grid>
                      <Row>
                      <Text style={styles.slideText}>{I18n.t('intros.intro2')}</Text>
</Row>

                          <Row style={styles.slide2Row}>
                            <CheckBox
                              label={I18n.t('services.all')}
                              labelStyle = {styles.slide2RowText}
                              checkboxStyle = {{color: '#838383', underlayColor: '#335075'}}
                              checked={
                                 (this._includeSchoolSectors(this.props.filters.sectors))
                                 && this.props.filters.sectors.includes("06 health and social services")
                                 && this.props.filters.sectors.includes("02 culture")
                              }
                              onChange={(checked)=> {
                                  // console.log(checked);
                                  // console.log(this.props.filters);
                                  if (checked){
                                    this._deleteSchoolSectors();
                                    this._deleteSector("06 health and social services");
                                    this._deleteSector("02 culture");
                                  }else{
                                    this._addSchoolSectors();
                                    this._addSector("06 health and social services");
                                    this._addSector("02 culture");
                                  }}}
                                          />
                          </Row>
                          <Row style={styles.slide2Row}>
                            <CheckBox
                            label={I18n.t('services.school', { locale: language })}
                            labelStyle = {styles.slide2RowText}
                            checked={this._includeSchoolSectors(this.props.filters.sectors)}
                            onChange={(checked)=> {
                              // console.log(checked);
                              // console.log(this.props.filters);
                            (checked) ? this._deleteSchoolSectors() : this._addSchoolSectors() }}
                            />
                          </Row>
                          <Row style={styles.slide2Row}>
                            <CheckBox
                            label={I18n.t('services.health', { locale: language })}
                            labelStyle = {styles.slide2RowText}
                            checked={this.props.filters.sectors.includes("06 health and social services")}
                            onChange={(checked)=> {
                              // console.log(checked);
                              // console.log(this.props.filters);
                            (checked) ? this._deleteSector("06 health and social services") : this._addSector("06 health and social services")}}
                            />
                          </Row>
                          <Row style={styles.slide2Row}>
                            <CheckBox
                            label={I18n.t('services.culture', { locale: language })}
                            labelStyle = {styles.slide2RowText}
                            checked={this.props.filters.sectors.includes("02 culture")}
                            onChange={(checked)=> {
                              // console.log(checked);
                              // console.log(this.props.filters);
                            (checked) ? this._deleteSector("02 culture") : this._addSector("02 culture")}}
                            />
                          </Row>
</Grid>
                      </Content>
                  </Container>
      </View>
      <View style={styles.slide}>
      <Text style={styles.slideTitle}>{I18n.t('intros.intro3Title')}</Text>
      <Text style={styles.slideText}>{I18n.t('intros.intro3')}</Text>
      <View style={styles.slide3ButtonGroup}>
      <Button block style={styles.slide3Button}
              onPress={this._onLanguageButtonPress.bind(this, "en")}>
              <Text style={styles.slide3ButtonText}>{I18n.t('intros.intro3EnglishButton', { locale: language })}</Text>
          </Button>

                  <Button block style={styles.slide3Button}
                          onPress={this._onLanguageButtonPress.bind(this, "fr")}
                          color="#841584">
                          <Text style={styles.slide3ButtonText}>{I18n.t('intros.intro3FrenchButton', { locale: language })}</Text>
                      </Button>
      </View>

      </View>
      </Swiper>
    )}
}

const mapStateToProps = (state) => ({
    filters: state.Filters
  });

export default connect(
    mapStateToProps,
)(WalkThrough);
