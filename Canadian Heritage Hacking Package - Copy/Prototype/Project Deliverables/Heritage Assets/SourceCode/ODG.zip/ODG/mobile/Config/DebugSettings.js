const SETTINGS = {
  reduxLogging: __DEV__
}

export default SETTINGS
