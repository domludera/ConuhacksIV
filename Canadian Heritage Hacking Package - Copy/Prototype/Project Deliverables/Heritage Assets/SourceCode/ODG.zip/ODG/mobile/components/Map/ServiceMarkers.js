import React, { PropTypes } from 'react';
import {
  StyleSheet,
  View,
  Alert,
  Text,
  Dimensions,
  TouchableOpacity,
  ScrollView,
  PermissionsAndroid,
  Platform,
} from 'react-native';
// eslint-disable-next-line max-len
import SyntheticEvent from 'react-native/Libraries/Renderer/src/renderers/shared/shared/event/SyntheticEvent';
//import SyntheticEvent from 'react-native';
import MapView from 'react-native-maps';

import ServiceList from './ServiceList.js';

import { Button, Container, Content, List, ListItem, Icon, Left, Body, Right } from 'native-base';

import * as PlaceSearchActionCreators from '../../reducers/PlaceSearchActionCreators';
import * as ServicesActionCreators from '../../reducers/ServicesActionCreators';


//import Geocoder from 'react-native-geocoder';

import Geocoder from 'react-native-geocoding';

import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import ServicesResource from '../../reducers/resources';
import MyLocationMapMarker from './examples/MyLocationMapMarker';
//const store = configStore();
import isEqual from 'lodash/isEqual';

const { width, height } = Dimensions.get('window');

const ASPECT_RATIO = width / height;
const LATITUDE = 45.42825;
const LONGITUDE = -75.692;
const LATITUDE_DELTA = 0.0122;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;
let id = 0;

class Event extends React.Component {
  shouldComponentUpdate(nextProps) {
    return this.props.event.id !== nextProps.event.id;
  }

  render() {
    const { event } = this.props;
    return (
      <View style={styles.event}>
        <Text style={styles.eventName}>{event.name}</Text>
        <Text style={styles.eventData}>{JSON.stringify(event.data, null, 2)}</Text>
      </View>
    );
  }
}

Event.propTypes = {
  event: PropTypes.object,
};


// eslint-disable-next-line react/no-multi-comp
class ServiceMarkers extends React.Component {

  constructor(props) {
    super(props);
    this.state = {

    mySwitch: false,
    mapDidRender: false,

    currentPosition: null,
    didCenterOnUserLocation: false,

      userCurrentRegion: {
        "latitude": 45.74083333,
        "latitudeDelta": 0.1,
        "longitudeDelta": 0.15,
        "longitude": -75.92750000,
      },

      searchQuery: {
        "regionrect":{
        "tllat":45.74083333,
        "tllon":-75.92750000,
        "brlat":45.74083333,
        "brlon":-75.92750000
        },
        "language":this.props.filters.language,//"fr" or "en"
        "regioncode":"pr001",
        "provincecode": this.props.filters.provinceCode,//"pr24" or "!pr24"
        "sectors":this.props.filters.sectors,
      },

      region: {
        latitude: LATITUDE,
        longitude: LONGITUDE,
        latitudeDelta: LATITUDE_DELTA,
        longitudeDelta: LONGITUDE_DELTA,
      },

      events: [],
    };
  }

  watchID: ?number = null;

 componentDidMount() {
   this.mounted = true;
   this.state.mySwitch = true;
   this.state.mapDidRender = false;

   navigator.geolocation.getCurrentPosition(
     (position) => {
       this.setState({currentPosition: position.coords});
     },

     (error) => console.log(JSON.stringify(error)),
     {enableHighAccuracy: true, timeout: 50000, maximumAge: 10000}
   );
   this.watchID = navigator.geolocation.watchPosition((position) => {
     this.setState({currentPosition: position.coords});
   },
   (error) => console.log(JSON.stringify(error)),
 );
 }

 componentWillUnmount() {
  navigator.geolocation.clearWatch(this.watchId);
}

componentWillReceiveProps(nextProps) {
  if(nextProps && this.props && nextProps.selectedService && this.props.selectedService) {
    var oldService = this.props.selectedService;
    var newService = nextProps.selectedService
    if(newService !== oldService) {
      this.refs.scrollView.scrollTo(0)
    }
  }
}

  makeEvent(e, name) {
    return {
      id: id++,
      name,
      data: e.nativeEvent ? e.nativeEvent : e,
    };
  }

  recordEvent(name) {
    return e => {
      if (e instanceof SyntheticEvent && typeof e.persist === 'function') {
        e.persist();
      }
      this.setState(prevState => ({
        events: [
          this.makeEvent(e, name),
          ...prevState.events.slice(0, 10),
        ],
      }));
    }
  }

  convertMapCoordinatesToSearchRegionRect(coords) {
    return {

    "tllat":coords.latitude + (coords.latitudeDelta / 2),
    "tllon":coords.longitude - (coords.longitudeDelta /2),
    "brlat":coords.latitude - (coords.latitudeDelta / 2),
    "brlon":coords.longitude + (coords.longitudeDelta / 2),
    }
  }

  convertPlaceSearchResultGeometryToSearchRegionRect(geometry) {
    return {
      "tllat":geometry.location.lat + (LATITUDE_DELTA / 2),
      "tllon":geometry.location.lng - (LONGITUDE_DELTA /2),
      "brlat":geometry.location.lat - (LATITUDE_DELTA / 2),
      "brlon":geometry.location.lng + (LONGITUDE_DELTA / 2),
    }
  }

  convertLatLonToSearchRegionRect(latlon) {
    return {
      "tllat":latlon.latitude + (LATITUDE_DELTA / 2),
      "tllon":latlon.longitude - (LONGITUDE_DELTA /2),
      "brlat":latlon.latitude - (LATITUDE_DELTA / 2),
      "brlon":latlon.longitude + (LONGITUDE_DELTA / 2),
    }
  }

  setSearchRegion(name) {
    return e => {
      console.log("setSearchRegion", e);
      console.log("user current region", this.state.userCurrentRegion);

      //workaround for strange lage deltas
      if (e.longitudeDelta < 30 || e.latitudeDelta < 30){
            if (e instanceof SyntheticEvent && typeof e.persist === 'function') {
              e.persist();
            }
            this.setState(prevState => ({
              userCurrentRegion: e,
              searchQuery: {
                "regionrect": this.convertMapCoordinatesToSearchRegionRect(e),
                "language":this.props.filters.language,//"fr" or "en"
                "regioncode":"pr001",
                "provincecode": this.props.filters.provinceCode,//"pr24" or "!pr24"
                "sectors":this.props.filters.sectors,
              }
            }));
      }
      //todo: reverse geocode
  //    this._onNewSearchQuery(e);

      //console.log(this.convertMapCoordinatesToSearchRegionRect(this.state.userCurrentRegion));
    };
  }


  setSearchRegionToPlaceSearchResult(regionrect) {
    this.setState(prevState => ({
      searchQuery: {
        "regionrect": regionrect,
        "language":this.props.filters.language,//"fr" or "en"
        "regioncode":"pr001",
        "provincecode": this.props.filters.provinceCode,//"pr24" or "!pr24"
        "sectors":this.props.filters.sectors,
      }
    }));
  }

  goToUserLocation(pos) {
    this.refs.map.animateToRegion({
      latitude: pos.latitude,
      longitude: pos.longitude,
      latitudeDelta: LATITUDE_DELTA,
      longitudeDelta: LONGITUDE_DELTA,
    },3000);
  }

  moveMapToLocation(latlng) {
    this.setState( {
      region: {
        latitudeDelta: LATITUDE_DELTA,
        longitudeDelta: LONGITUDE_DELTA,

      }
    })
  }

  moveMapIfServiceSelected() {

  }

  mapMovedToServiceLocation() {
    let {dispatch} = this.props;
    let action = ServicesActionCreators.clearSelectedService();
    dispatch(action);
  }

  _onPlaceSearchDetailsRecieved ()  {
  let { dispatch } = this.props;
  //filters.language = language;
  let action = PlaceSearchActionCreators.stopUntilNextSearch();
  dispatch(action);

};

  goToPlaceSearchSelectedLocation(newRegion) {
    console.log("MarkerList: place search go to location.", newRegion);
    this.refs.map.animateToRegion({
        longitude: newRegion.geometry.location.lng,
        longitudeDelta: LONGITUDE_DELTA * 5,
        latitudeDelta: LATITUDE_DELTA * 5,
        latitude: newRegion.geometry.location.lat,
    }, 3000)

    // this._onPlaceSearchDetailsRecieved();
    this._onPlaceSearchDetailsRecieved();
    this.setSearchRegionToPlaceSearchResult(newRegion.geometry);

    this.setState( {
      mySwitch: false
    })
}

  moveToLocationIfSwitchOk() {
    if(this.props.placeSearch) {
      if(this.props.placeSearch.placeSearchInvoked && this.state.mapDidRender) {
        console.log("MarkerList: place search map nav invoked", this.props.placeSearch.searchResultData);

        // this.props.placeSearch.searchResultData.geometry.location.lat
        // this.props.placeSearch.searchResultData.geometry.location.lng
        this.goToPlaceSearchSelectedLocation(this.props.placeSearch.searchResultData);

      }

    }
  }

  renderBackButton() {
    return (
      <TouchableOpacity
        style={styles.back}
        onPress={() => this.goToUserLocation() }
      >
        <Text style={{ fontWeight: 'bold', fontSize: 30 }}>&larr;</Text>
      </TouchableOpacity>
    );
  }

  setMapDidRender() {
    this.state.mapDidRender = true;
  }

  onMarkerPress() {

  }

  centerOnUserLocationOnce() {
    if (!this.state.didCenterOnUserLocation && (this.state.currentPosition)) {
      this.refs.map.animateToRegion({
        latitude: this.state.currentPosition.latitude,
        longitude: this.state.currentPosition.longitude,
        latitudeDelta: LATITUDE_DELTA * 4,
        longitudeDelta: LONGITUDE_DELTA * 4,
      },3000);
      this.setState( {
        didCenterOnUserLocation: true
      })
    }
  }

  doSelectService(service) {
    console.log('Setting selected service to ', (JSON.stringify(service)));
    let {dispatch} = this.props;
    let action = ServicesActionCreators.setSelectedService(service);
    dispatch(action);
  }

  isSelectedServiceName(service) {
    if(this.props.selectedService) {
      return (this.props.selectedService.name === service.name);
    }
    return false;
  }

  render() {
    const { currentPosition } = this.state;
    console.log('service selected?: ', this.props.selectedService );

    return (
      <View style={styles.container}>
      <ScrollView ref="scrollView" style={styles.scrollview}>
        <MapView
          ref="map"
          provider={this.props.provider}
          style={styles.map}
          initialRegion={this.state.region}
         onRegionChangeComplete={this.setSearchRegion('Map::onRegionChangeComplete')}
        >
            <MyLocationMapMarker
            />
            {this.props.services.filter(service => (
                  (Number(service.latitude) >= (this.state.userCurrentRegion.latitude - this.state.userCurrentRegion.latitudeDelta)
                  &&   Number(service.latitude) <= (this.state.userCurrentRegion.latitude + this.state.userCurrentRegion.latitudeDelta)
                  &&   Number(service.longitude) >= (this.state.userCurrentRegion.longitude - this.state.userCurrentRegion.longitudeDelta)
                  &&   Number(service.longitude) <= (this.state.userCurrentRegion.longitude + this.state.userCurrentRegion.longitudeDelta))
               )
             )
             .map(service => (
              <MapView.Marker
              onPress={ () => {
                this.doSelectService(service); //also send reference?
              }}
              image={
                this.isSelectedServiceName(service)
                ? require('../../assets/ic_Pin_selected.png')
                : require('../../assets/ic_Pin_blue.png')
              }
                coordinate={{
                latitude: Number(service.latitude),
                longitude: Number(service.longitude),
              }}
                title={service.name}
              />
            ))
          }
        </MapView>

        {this.moveToLocationIfSwitchOk()}
        {this.setMapDidRender()}
        {this.moveMapIfServiceSelected()}
        {this.centerOnUserLocationOnce()}

        <TouchableOpacity
          style={styles.back}
          onPress={() => this.goToUserLocation(this.state.currentPosition) }
        >
          <Icon name="md-locate"/>
        </TouchableOpacity>

        <View style={styles.eventList}>
          <ScrollView>
            <ServiceList  searchQuery={this.state.searchQuery}></ServiceList>
          </ScrollView>
        </View>
        </ScrollView>
      </View>
    );
  }
}

ServiceMarkers.propTypes = {
  provider: MapView.ProviderPropType,
};

const SIZE = 35;
const HALO_RADIUS = 6;
const ARROW_SIZE = 7;
const ARROW_DISTANCE = 6;
const HALO_SIZE = SIZE + HALO_RADIUS;
const HEADING_BOX_SIZE = HALO_SIZE + ARROW_SIZE + ARROW_DISTANCE;

const styles = StyleSheet.create({
  callout: {
    width: 60,
  },
  container: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  scrollview: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'white',
  },
  event: {
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    padding: 8,
  },
  eventData: {
    fontSize: 10,
    fontFamily: 'Roboto',
    color: '#555',
  },
  eventName: {
    fontSize: 13,
    fontFamily: 'Roboto',
    fontWeight: 'bold',
    color: '#222',
  },
  eventList: {
    backgroundColor:'white',
    zIndex: 1,
    position: 'relative',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
    position: 'relative',
    top: 0,
    left: 0,
    right: 0,
    bottom: height / 4,
    height: 400
  },
  bubble: {
    backgroundColor: 'rgba(255,255,255,0.7)',
    paddingHorizontal: 18,
    paddingVertical: 12,
    borderRadius: 20,
  },
  latlng: {
    width: 200,
    alignItems: 'stretch',
  },
  button: {
    width: 80,
    paddingHorizontal: 12,
    alignItems: 'center',
    marginHorizontal: 10,
  },
  buttonContainer: {
    flexDirection: 'row',
    marginVertical: 20,
    backgroundColor: 'transparent',
  },
  back: {
    position: 'absolute',
    top: 20,
    right: 12,
    backgroundColor: 'rgba(255,255,255,0.4)',
    padding: 12,
    borderRadius: 20,
    width: 80,
    alignItems: 'center',
    justifyContent: 'center',
  },
  heading: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: HEADING_BOX_SIZE,
    height: HEADING_BOX_SIZE,
    alignItems: 'center',
  },
  headingPointer: {
    width: 0,
    height: 0,
    backgroundColor: 'transparent',
    borderStyle: 'solid',
    borderTopWidth: 0,
    borderRightWidth: ARROW_SIZE * 0.75,
    borderBottomWidth: ARROW_SIZE,
    borderLeftWidth: ARROW_SIZE * 0.75,
    borderTopColor: 'transparent',
    borderRightColor: 'transparent',
    borderBottomColor: 'red',
    borderLeftColor: 'transparent',
  },
  markerHalo: {
    position: 'absolute',
    backgroundColor: 'white',
    top: 0,
    left: 0,
    width: HALO_SIZE,
    height: HALO_SIZE,
    borderRadius: Math.ceil(HALO_SIZE / 2),
    margin: (HEADING_BOX_SIZE - HALO_SIZE) / 2,
    shadowColor: 'black',
    shadowOpacity: 0.25,
    shadowRadius: 2,
    shadowOffset: {
      height: 0,
      width: 0,
    },
  },
});


const mapStateToProps = (state) => ({
    services: Object.values(state.Services.List),
    placeSearch: state.PlaceSearch,
    filters: state.Filters,
    error: state.Services.error,
    loading: state.Services.loading,
    selectedService: state.Services.selected,
});

// const mapDispatchToProps = (dispatch) => bindActionCreators(
//     ServicesResource.actionCreators,
//     dispatch
// );

function mapDispatchToProps(dispatch) {
  return {
    serviceActions: bindActionCreators(ServicesResource.actionCreators, dispatch),
    pleaceSearchActions: bindActionCreators(PlaceSearchActionCreators, dispatch)
  }
}

export default connect(
    mapStateToProps,
)(ServiceMarkers);
