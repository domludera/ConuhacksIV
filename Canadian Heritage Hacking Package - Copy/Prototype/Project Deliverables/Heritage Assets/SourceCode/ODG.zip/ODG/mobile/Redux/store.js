import { createStore, applyMiddleware, compose, combineReducers } from 'redux';
import { Platform } from 'react-native';
import devTools from 'remote-redux-devtools';
import Thunk from 'redux-thunk';
import ServicesResource from '../reducers/resources';
import ServicesReducer from '../reducers/ServicesReducer';
import FiltersReducer from '../reducers/FiltersReducer';
import PlaceSearchReducer from '../reducers/PlaceSearchReducer';
import createSagaMiddleware from 'redux-saga'
import rootSaga from '../Sagas/'
import ReduxPersist from '../Config/ReduxPersist'
import { autoRehydrate } from 'redux-persist'
import RehydrationServices from '../Services/RehydrationServices'

export default function configStore(){
  const sagaMiddleware = createSagaMiddleware();
  const middleware = []
  middleware.push(sagaMiddleware)
  middleware.push(ServicesResource.middleware)
  const enhancers = []
  if (ReduxPersist.active) {
      enhancers.push(autoRehydrate())
    }
    enhancers.push(applyMiddleware(...middleware))
  const store = createStore(
    combineReducers({
        Services: ServicesReducer,
        Filters:FiltersReducer,
        PlaceSearch: PlaceSearchReducer,
        settings: require('./SettingsRedux').reducer
    }),
    compose(...enhancers)
  );
  if (ReduxPersist.active) {
    RehydrationServices.updateReducers(store)
  }
  sagaMiddleware.run(rootSaga)
  return store;
}
