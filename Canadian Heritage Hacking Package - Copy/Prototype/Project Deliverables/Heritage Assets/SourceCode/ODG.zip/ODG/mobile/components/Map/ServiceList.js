import React,{ Component }  from 'react';
import { AppRegistry,
    ActivityIndicator,
    Dimensions,
    StyleSheet,
    FlatList,
    Image,
    View } from 'react-native';

import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import * as ServicesActionCreators from '../../reducers/ServicesActionCreators';
import ServicesResource from '../../reducers/resources';

import { Button, Container, Content, List, ListItem, Icon, Left, Body, Right, Text } from 'native-base';
import { Col, Row, Grid } from 'react-native-easy-grid';
import I18n from 'react-native-i18n'
const DEVICE_WIDTH = Dimensions.get(`window`).width;
const { width, height } = Dimensions.get('window');

const ASPECT_RATIO = width / height;

const LATITUDE_DELTA = 0.0022;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

import Swipeout from 'react-native-swipeout';

const styles = StyleSheet.create({
    container: {
    },
    listItem: {
      flex: 1,
      //flexDirection:'row',
      width: DEVICE_WIDTH,
      height: 'auto',
      //alignItems: 'flex-start',
      //justifyContent: 'flex-start',
      paddingTop:10,
      paddingBottom: 10,
    },
    itemLeft: {
      flex: -1,
      width: 'auto'
      // flexDirection:'column',
    },
    itemBody: {
      //width: 'auto'
      // flexDirection:'column',
      // alignItems: 'flex-start',
      // justifyContent: 'flex-start',
    },
    itemRight: {
      // flex: 0,
       flexDirection:'column',
      justifyContent: 'center',
    },
    itemRightRow1: {
      // flex: 0,
      // flexDirection:'row',
      // alignItems: 'flex-end',
      // justifyContent: 'flex-end',
    },
    itemRightRow2: {
      // flex: 0,
      flexDirection:'row',
       alignItems: 'flex-end',
       justifyContent: 'flex-end',
    },
    topRow: {
      height: 'auto',
      flex: -1,
      justifyContent: 'flex-start',
      position: 'absolute',
      top: 0,
      right: 200,
    },
    listMain: {
      flex: 1,
      position: 'absolute',
      top: 150,
    },
    swipeOut: {
    },
    listBgn: {
      backgroundColor: 'white',
    },
    noResults: {
      flex: 0,
      justifyContent: 'center',
      alignItems: 'center',
      position: 'relative',
      right: 0,
      marginTop: 15,
      marginBottom: 15,
    }
});

// Buttons
var swipeoutBtns = [
{
  backgroundColor: '#335075',
  component: <View style={styles.swipeout}>
  <Icon outline name="md-heart-outline"  style={{color: "white", position: 'relative', top: 10, left: 25}} onPress={() => {
}}/>
  <Icon name="md-share" style={{color: "white", position: 'relative', top: 10, left: 25}}/></View>,
  text: 'Button',
}
]
//  component: <View><Text>'md-heart'</Text></View>,

class GetAll extends React.Component {


  constructor(props) {
    super(props);
  }

  componentDidMount() {
        //this.props.index(); // Get all the Services
        let {dispatch} = this.props;
        let action = ServicesResource.actionCreators.create(this.props.searchQuery);
        dispatch(action);

}
componentWillReceiveProps(nextProps) {
  if(nextProps.searchQuery) {
    console.log("ServiceList.componentWillReceiveProps:this.props = ", this.props)
    console.log("ServiceList.componentWillReceiveProps:nextProps = ", nextProps)

    // if(this.props.filters.sectors != nextProps.searchQuery.sectors) {
    //   //nextProps.searchQuery.sectors = this.props.filters.sectors;
    //   //this.props.create(nextProps.searchQuery);
    //   let {dispatch} = this.props;
    //   let action = ServicesResource.actionCreators.create(nextProps.searchQuery);
    //   dispatch(action);
    // }

    if(this.props.searchQuery === nextProps.searchQuery
       && nextProps.filters.sectors === nextProps.searchQuery.sectors
     && nextProps.filters.language === nextProps.searchQuery.language
     && nextProps.filters.provinceCode === nextProps.searchQuery.provincecode) {
         console.log("search query no change")
    }else{
      let {dispatch} = this.props;
      nextProps.searchQuery.sectors = nextProps.filters.sectors
      nextProps.searchQuery.language = nextProps.filters.language
      nextProps.searchQuery.provincecode = nextProps.filters.provinceCode
      let action = ServicesResource.actionCreators.create(nextProps.searchQuery);
      dispatch(action);
    }
  }
}


  doSelectService(service, index) {
    let {dispatch} = this.props;
    let action = ServicesActionCreators.setSelectedService(service);
    dispatch(action);

    let searchQuery = this.props.searchQuery;
    searchQuery.regionrect = this.convertLatLonToSearchRegionRect(service);
    let newSearchAction = ServicesResource.actionCreators.create(searchQuery);
    dispatch(action);
    //alert(JSON.stringify(service));

    this.forceUpdate();

  }

  convertLatLonToSearchRegionRect(latlon) {
    return {
      "tllat":latlon.latitude + (LATITUDE_DELTA / 2),
      "tllon":latlon.longitude - (LONGITUDE_DELTA /2),
      "brlat":latlon.latitude - (LATITUDE_DELTA / 2),
      "brlon":latlon.longitude + (LONGITUDE_DELTA / 2),
    }
  }

  setServiceArraySliceIndex(index) {
    let {dispatch} = this.props;
    let action = ServicesActionCreators.setSelectedService(service);
    dispatch(action);

  }

  compareServicesToSelectedService(selectedServiceName) {
    return function(a,b) {
      if(a.name === selectedServiceName) {
        return -1;
      }
      if(b.name === selectedServiceName) {
        return 1;
      }
      return 0;
    }
  }

    render() {
      var serviceToPng = {"06 health and social services":require("../../assets/ic_health_social_services_outline.png"),
                           "02 culture":require("../../assets/ic_culture.png"),
                           "00 school":require("../../assets/ic_education_focus.png")};
                           var path = serviceToPng["00 school"]
          return (

              <View style={styles.container}>
              <List>
                  {!this.props.loading && !this.props.error && (this.props.Services.length > 0)
                      ? this.props.Services
                      .slice(0)
                      .sort(this.compareServicesToSelectedService(
                        this.props.selectedService ? this.props.selectedService.name : ""))
                      .map((service, index) => (

                          <Swipeout right={swipeoutBtns}>
                            <View style={styles.listBgn}>
                            <ListItem
                            onPress={() => {
                              this.doSelectService(service, index);
                            }}
                            style={styles.listItem}>

                              <Image source={serviceToPng[service.sector]} />

                              <Body style = {styles.itemBody}>
                                <Text style={{fontFamily: 'Roboto'}}>{service.name}</Text>
                                <Text note style={{fontFamily: 'Roboto'}}>{service.city}, {service.province} {service.postCode}</Text>
                                <Text note style={{fontFamily: 'Roboto'}}>{I18n.t('serviceList.minority')}</Text>
                                <Text note style={{fontFamily: 'Roboto'}}>{service.minorityPopNumber}, {service.minorityPopPercentage}</Text>
                              </Body>
                              <Right style={styles.itemRight}>
                                  <Row>
                                    <Button transparent iconRight>
                                    <Icon name={'md-heart-outline'} style={{color: '#F27242'}} />
                                    </Button>
                                  </Row>

                                <Row style={{flex: 1, flexDirection: 'row', alignItems:'flex-end', justifyContent: 'flex-end'}}>
                                <Text>{ Number(service.distance).toPrecision(2)} km </Text><Icon name={'md-navigate'} style={{color: 'black', marginLeft: 5}}/>
                                </Row>
                              </Right>
                              </ListItem>
                          </View>
                          </Swipeout>
                      ))
                      : null
                  }
                  {!this.props.loading && !this.props.error && (this.props.Services.length < 1)
                    ? <View style={styles.noResults}>
                      <Text>No results available for the search criteria.</Text>
                      </View>
                    : null
                  }
                  {this.props.loading
                      ? <ActivityIndicator />
                      : null
                  }
                  {this.props.error
                      ? <Text>{this.props.error.message}</Text>
                      : null
                  }
                  </List>
              </View>
          );
      }
}

const mapStateToProps = (state) => ({
    Services: Object.values(state.Services.List),
    error: state.Services.error,
    loading: state.Services.loading,
    selectedService: state.Services.selected,
    filters: state.Filters,
});
const mapDispatchToProps = (dispatch) => bindActionCreators(
    ServicesResource.actionCreators,
    dispatch
);


export default connect(
    mapStateToProps,
)(GetAll);
