import React, { Component } from 'react'
import {
  Modal,
  View,
  Image,
  Switch,
  StatusBar,
  TouchableHighlight,
  PropTypes,
  Dimensions
} from 'react-native'
import { Container, Button, Content, Header, Title, List, ListItem, Text, Radio, Icon, Item, Left, Right, Body} from 'native-base';
const { width, height } = Dimensions.get('window')

const DEVICE_WIDTH = Dimensions.get(`window`).width;

var {GooglePlacesAutocomplete} = require('react-native-google-places-autocomplete');

import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import  LocationSearch from './LocationSearch';

import * as PlaceSearchActionCreators from '../../reducers/PlaceSearchActionCreators';

class LocationModal extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      searchModalVisible: false,
    };

  };

  _setModalVisible = (visible) => {
    if(visible) {
      let {dispatch} = this.props;
      let action = PlaceSearchActionCreators.setModalShouldClose(false);
      dispatch(action);
    }
    this.setState({searchModalVisible: visible});
  }

  _getLocationText() {
    return this.locationSearch.getWrappedInstance().getLocationText();
  }

    render() {

      console.log("LOGGING SearchModal state:", this.state);
      console.log("LOGGING SearchModal props:",this.props);
      console.log("LOGGING SearchModal SEARCHINVOKED", this.props.placeSearch.placeSearchInvoked);
      // if(this.props.placeSearch.pleaceSearchInvoked) {
      //   this.setState({searchModalVisible: false});
      // }

      return(
        <View style={{paddingTop: 0, backgroundColor:'green'}}>
        <Modal

           animationType={"slide"}
           transparent={false}
           visible={ this.state.searchModalVisible && !(this.props.modalShouldClose)}
           onRequestClose={() => {alert("Modal has been closed.")}}
           >

          <View style={{flex: 1,
          backgroundColor:'white',width: DEVICE_WIDTH, position: 'relative', left: 0}}>
            <LocationSearch ref={instance => { this.locationSearch = instance; }}  />
          </View>

          <Button onPress={this._setModalVisible.bind(this, false)} transparent
            style={{flex: 1, position: 'absolute', top: 8, zIndex: 10,}}
          >
              <Icon  name="close" style={{alignItems: 'flex-start', fontSize: 32}} />
          </Button>
         </Modal>

         </View>

      )
    }

  }

// LocationModal.propTypes = {
//   store: PropTypes.object.isRequired
// };
//
// module.exports = LocationModal;

// function mapStateToProps(state) {
//   return { modalVisible: state.modalVisible };
// }
//
// function mapDispatchToProps(dispatch) {
//   return { actions: bindActionCreators(PlaceSearchActionCreators, dispatch) };
// }

// const mapStateToProps = (state, { todoListId }) => ({
//   ...getTodoList(state, todoListId), // A todo object (assume we need all the attributes)
//   visibleTodos: getVisibleTodos(state, todoListId), // returns ids
// });

// class LocationModal extends React.Component {
//
//   constructor(props) {
//     super(props);
//
//     // this.state = {
//     //   modalVisible: false,
//     // };
//
//   };
//
//     componentDidMount() {
//       //this.props.create(this.props.modalVisible);
//       console.log("LocationModal componentDidMount");
//       console.log(this.props);
//     }
//
//     _setModalVisible = (visible) => {
//       console.log('LocaitonModal: set modal visible.')
//       this.setState({modalVisible: visible});
//     };
//
//     render() {
//       return (
    // <View>
    // <Modal
    //    animationType={"slide"}
    //    transparent={false}
    //    visible={this.props.modalVisible}
    //    onRequestClose={() => {alert("Modal has been closed.")}}
    //    >
    //  </Modal>
    //
    // </View>
//   );
//     }
// }

const mapStateToProps = (state) => ({
  placeSearch: state.PlaceSearch,
  searchResultData: state.searchResultData,
  placeSearchData: state.searchResultData,
  placeSearchInvoked: state.PlaceSearch.placeSearchInvoked,
  modalShouldClose: state.PlaceSearch.modalShouldClose,
});
const mapDispatchToProps = (dispatch) => bindActionCreators(
    PlaceSearchActionCreators,
    dispatch
);

export default connect(
    mapStateToProps,
    null, null,
    {withRef: true}
)(LocationModal);
