import React,{ Component }  from 'react';
import { AppRegistry,
    ActivityIndicator,
    StyleSheet,
    Text,
          Dimensions,
    View } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PostsResource from '../resources';

import MapView from 'react-native-maps';

const { width, height } = Dimensions.get('window');

const ASPECT_RATIO = width / height;
const LATITUDE = 37.78825;
const LONGITUDE = -122.4324;
const LATITUDE_DELTA = 0.0922;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

const styles = StyleSheet.create({
    container: {}
});

class GetAllMarkers extends React.Component {
  componentDidMount() {
        //this.props.index(); // Get all the posts
        this.props.create({
  "regionrect":{
  "tllat":45.54083333,
  "tllon":-75.92750000,
  "brlat":45.32000000,
  "brlon":-75.61027778
  },
"language":"en",
"regioncode":"pr001",
"category":"education"
}); // Create a post
        //setTimeout(() => this.props.read(this.props.posts[0].id), 5000); // Get a post
        //setTimeout(() => this.props.create({ content: 'Hello There!' }), 10000); // Create a post
        //setTimeout(() => this.props.delete(1), 20000); // Delete the post of ID 1
    }
    render() {
          return (
            <View>
                  {!this.props.loading && !this.props.error
                      ? this.props.posts.map((post) => (
//                           <View key={post.sourceCode}>
//                               <Text>{post.name} Lat: {post.latitude} Lon: {post.longitude}</Text>
//                           </View>
//                         <MapView.Marker
//                           coordinate={{
//                             latitude: {post.latitude},
//                             longitude: {post.longitude},
//                           }}
//                         />

          <MapView.Marker key={post.sourceCode}
            coordinate={{
              latitude: LATITUDE - (LATITUDE_DELTA / 2),
              longitude: LONGITUDE - (LONGITUDE_DELTA / 2),
            }}
          />
                      ))
                      : null
                  }
                  {this.props.loading
                      ? <ActivityIndicator />
                      : null
                  }
                  {this.props.error
                      ? <Text>{this.props.error.message}</Text>
                      : null
                  }
            </View>
          );
      }
}

const mapStateToProps = (state) => ({
    posts: Object.values(state.Posts.List),
    error: state.Posts.error,
    loading: state.Posts.loading,
});
const mapDispatchToProps = (dispatch) => bindActionCreators(
    PostsResource.actionCreators,
    dispatch
);

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(GetAllMarkers);
