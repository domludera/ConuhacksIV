import React,{ Component }  from 'react';
import { AppRegistry,
    ActivityIndicator,
    StyleSheet,
    Button,
    Alert,
    Text,
    View } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import ServicesResource from './reducers/resources';
import * as FiltersActionCreators from './reducers/FiltersActionCreators';

const styles = StyleSheet.create({
    container: {}
});


class TestStore extends React.Component {
    _onButtonPress()  {
      Alert.alert('Button has been pressed!');
      let { dispatch } = this.props
      let action = FiltersActionCreators.update({
          language: "fr",
          provinceCode: "pr24", //outside
          sector:"ddd",
      })
      dispatch(action)
    };
    componentDidMount() {
      let { dispatch } = this.props;
      let actionGetServices = ServicesResource.actionCreators.create({
                                "regionrect":{
                                "tllat":45.54083333,
                                "tllon":-75.92750000,
                                "brlat":45.32000000,
                                "brlon":-75.61027778
                                },
                                "language":"en",//"fr" or "en"
                                "regioncode":"pr001",
                                "provincecode":"!pr24",//"pr24" or "!pr24"
                                "category":"education"
                              });
      dispatch(actionGetServices);

    }
    render() {
      console.log(FiltersActionCreators);
          return (
              <View style={styles.container}>
              <Button
                onPress={this._onButtonPress.bind(this)}
                title="Press Me"
                accessibilityLabel="See an informative alert"
              />
              <Text>{this.props.language}:{this.props.proviceCode}:{this.props.sector}</Text>
                  {!this.props.loading && !this.props.error
                      ? this.props.services.map((service) => (
                          <View key={service.sourceCode}>
                              <Text>{service.name}</Text>
                          </View>
                      ))
                      : null
                  }
                  {this.props.loading
                      ? <ActivityIndicator />
                      : null
                  }
                  {this.props.error
                      ? <Text>{this.props.error.message}</Text>
                      : null
                  }
              </View>
          );
      }
}

const mapStateToProps = (state) => ({
    language: state.Filters.language,
    sector:state.Filters.sector,
    proviceCode:state.Filters.provinceCode,
    services: Object.values(state.Services.List),
    error: state.Services.error,
    loading: state.Services.loading,
});

export default connect(
    mapStateToProps,
)(TestStore);
