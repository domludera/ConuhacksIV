import React, { Component } from 'react'
import {
  Modal,
  View,
  Image,
  Switch,
  StatusBar,
  TouchableHighlight,
  Dimensions
} from 'react-native'
import { Container, Button, Content, Header, Title, List, ListItem, Text, Radio, Icon, Item, Left, Right, Body} from 'native-base';
const { width, height } = Dimensions.get('window')

const DEVICE_WIDTH = Dimensions.get(`window`).width;

import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as PlaceSearchActionCreators from '../../reducers/PlaceSearchActionCreators';


var {GooglePlacesAutocomplete} = require('react-native-google-places-autocomplete');

class LocationSearch extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      locationSearchResultData: 'none',
      locationSearchResultDetails: 'none',
    }

  }

  _getLocationText() {
    return this.state.locationSearchResultDetails;
  }

  _onSearchInvoked (data, details)  {
  let { dispatch, locationSearchResultData } = this.props;
  //filters.language = language;
  let action = PlaceSearchActionCreators.update(details)
  console.log("LocationSearch widget action:");
  console.log(action);
  dispatch(action);

};

  render() {
    return (
      <GooglePlacesAutocomplete
        placeholder='Search'
        minLength={2} // minimum length of text to search
        autoFocus={true}
        listViewDisplayed='true'    // auto/true/false/undefined
        fetchDetails={true}
        renderDescription={(row) => row.description} // custom description render
        onPress={(data, details = null) => { // 'details' is provided when fetchDetails = true
          this._onSearchInvoked(data, details);
        }}
        getDefaultValue={() => {
          return ''; // text input default value
        }}
        query={{
          // available options: https://developers.google.com/places/web-service/autocomplete
          key: 'AIzaSyDTtyvfgtgYKNDfI1M7_D_VBeje6P4hkYM',
          language: 'en', // language of the results
          types: '(cities)', // default: 'geocode'
        }}
        styles={{
          container: {
            backgroundColor:'white',
          },
          textInputContainer: {
            marginTop:10,
            marginLeft: 50,
           backgroundColor: 'rgba(0,0,0,0)',
           borderTopWidth: 0,
           borderBottomWidth:0
         },
         textInput: {
           fontSize: 16,
         },
          description: {
            fontWeight: 'bold',
          },
          predefinedPlacesDescription: {
            color: '#1faadb',
          },
          listView: {
            flex: 10,
            flexGrow: 100,
            flexDirection: 'column',
            backgroundColor: 'white',

            minHeight: 600,
          },
        }}

        currentLocation={false} // Will add a 'Current location' button at the top of the predefined places list
        currentLocationLabel="Current location"
        nearbyPlacesAPI='GooglePlacesSearch' // Which API to use: GoogleReverseGeocoding or GooglePlacesSearch
        GoogleReverseGeocodingQuery={{
          // available options for GoogleReverseGeocoding API : https://developers.google.com/maps/documentation/geocoding/intro
        }}
        GooglePlacesSearchQuery={{
          // available options for GooglePlacesSearch API : https://developers.google.com/places/web-service/search
          rankby: 'distance',
          types: 'food',
        }}


        filterReverseGeocodingByTypes={['locality', 'administrative_area_level_3']} // filter the reverse geocoding results by types - ['locality', 'administrative_area_level_3'] if you want to display only cities

      //  predefinedPlaces={[homePlace, workPlace]}

        debounce={200} // debounce the requests in ms. Set to 0 to remove debounce. By default 0ms.
      //  renderLeftButton={() => <Image source={require('path/custom/left-icon')} />}

      />
    );
  }
};

const mapStateToProps = (state) => ({
    placeSearch: state.PlaceSearch,
    placeSearchInvoked: state.PlaceSearch.placeSearchInvoked,
});

const mapDispatchToProps = (dispatch) => bindActionCreators(
    PlaceSearchActionCreators,
    dispatch
);

export default connect(
null,
null,
null,
  { withRef: true }
)(LocationSearch);
