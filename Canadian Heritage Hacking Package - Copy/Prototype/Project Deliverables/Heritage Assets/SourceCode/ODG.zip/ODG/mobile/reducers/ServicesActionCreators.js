export function update(query) {
  return {
    type: 'UPDATE',
    query
  }
}

export function setSelectedService(service) {
  return {
    type: 'SET-SELECTED',
    service
  }
}

export function clearSelectedService() {
  return {
    type: 'CLEAR-SELECTION'
  }
}

export function setSliceIndex(index) {
  return {
    type: 'SET-SLICE-INDEX',
    index
  }
}
