import React,{ Component }  from 'react';
import { AppRegistry,
    ActivityIndicator,
    Dimensions,
    StyleSheet,
    FlatList,
    Image,
    View } from 'react-native';

import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import I18n from 'react-native-i18n';

import { Button, Container, Content, List, ListItem, Icon, Left, Body, Right, Text } from 'native-base';
import { Col, Row, Grid } from 'react-native-easy-grid';

const DEVICE_WIDTH = Dimensions.get(`window`).width;
const { width, height } = Dimensions.get('window');


const styles = StyleSheet.create({
    container: {
      backgroundColor: 'white'
    },
    listItem: {
      flex: 1,
      //flexDirection:'row',
      width: DEVICE_WIDTH,
      height: 'auto',
      //alignItems: 'flex-start',
      //justifyContent: 'flex-start',
      paddingTop:10,
      paddingBottom: 10,
    },
    itemLeft: {
      flex: -1,
      width: 'auto'
      // flexDirection:'column',
    },
    itemBody: {
      //width: 'auto'
      // flexDirection:'column',
      // alignItems: 'flex-start',
      // justifyContent: 'flex-start',
    },
    itemRight: {
      // flex: 0,
       flexDirection:'column',
      justifyContent: 'center',
    },
    itemRightRow1: {
      // flex: 0,
      // flexDirection:'row',
      // alignItems: 'flex-end',
      // justifyContent: 'flex-end',
    },
    itemRightRow2: {
      // flex: 0,
      flexDirection:'row',
       alignItems: 'flex-end',
       justifyContent: 'flex-end',
    },
    topRow: {
      height: 'auto',
      flex: -1,
      justifyContent: 'flex-start',
      position: 'absolute',
      top: 0,
      right: 200,
    },
    listMain: {
      flex: 1,
      position: 'absolute',
      top: 150,
    },
    swipeOut: {
    }
});


class ForYou extends React.Component {
  static navigationOptions = ({ navigation, screenProps }) => ({
    tabBarLabel:I18n.t('main.tabs.forYou'),
  });

  constructor(props) {
    super(props);
  }


    render() {
          return (

<View style={styles.container}>
              <List>

                            <ListItem
                            style={styles.listItem}>
                              <Image source={require('../../assets/ic_education_focus.png')} />

                              <Body style = {styles.itemBody}>

                              <Text style={{fontFamily: 'Roboto', color:'#335075'}}>Chapel Hill Middle School</Text>
                                <Text style={{fontFamily: 'Roboto', color:'#000000'}}>Sector Education</Text>
                                <Text note style={{fontFamily: 'Roboto', color:'#000000'}}>Ottawa, Ontario, 0x0 x0x</Text>
                              </Body>
                              <Right style={styles.itemRight}>
                                  <Row style={styles.itemRightRow1}>
                                    <Image source={require('../../assets/ic_favorite_selected.png')} />
                                  </Row>

                                <Row style={styles.itemRightRow2}>
                                <Text> 2km </Text><Icon name={'md-navigate'} style={{color: 'black', marginLeft: 5}}/>
                                </Row>
                              </Right>
                              </ListItem>
                              <ListItem
                              style={styles.listItem}>
                                <Image source={require('../../assets/ic_culture.png')} />

                                <Body style = {styles.itemBody}>

                                <Text style={{fontFamily: 'Roboto', color:'#335075'}}>Lixar Culture Center</Text>
                                  <Text style={{fontFamily: 'Roboto', color:'#000000'}}>Sector: Culture</Text>
                                  <Text note style={{fontFamily: 'Roboto', color:'#000000'}}>Toronto, Ontario, 0x0 x0x</Text>
                                </Body>
                                <Right style={styles.itemRight}>
                                    <Row style={styles.itemRightRow1}>
                                      <Image source={require('../../assets/ic_favorite_selected.png')} />
                                    </Row>

                                  <Row style={styles.itemRightRow2}>
                                  <Text> 2km </Text>
                                  <Image source={require('../../assets/ic_location_arrow.png')} />
                                  </Row>
                                </Right>
                                </ListItem>
                  </List>
</View>
          );
      }
}

const mapStateToProps = (state) => ({

});
const mapDispatchToProps = (dispatch) => bindActionCreators(
);


export default connect(
    mapStateToProps,
)(ForYou);
