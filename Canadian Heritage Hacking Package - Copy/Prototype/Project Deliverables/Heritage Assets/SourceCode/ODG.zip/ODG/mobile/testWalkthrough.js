import React from 'react';
import { AppRegistry,Text} from 'react-native';
  import WalkThrough from './components/WalkThrough/'
  import PhotoView from './components/PhotoView';
  import Phone from './components/Phone';
AppRegistry.registerComponent('ODGMobile', () => WalkThrough);
