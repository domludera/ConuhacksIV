import React from 'react';
import './I18n/I18n'
import {
  AppRegistry,
  TextInput,
  StyleSheet,
  Dimensions,
  StatusBar,
  View,
  Image,
  Platform,
  FlatList
} from 'react-native';
import { Provider } from 'react-redux'
import configStore from './Redux/store'
import WalkThrough from './components/WalkThrough/';
import FilterModal from './components/Filters/';
import { TabNavigator, addNavigationHelpers } from 'react-navigation';
import { DrawerNavigator } from 'react-navigation';

import { StackNavigator } from 'react-navigation';
import { TabBarBottom } from 'react-navigation';
import { TabBarTop } from 'react-navigation';

//import SearchBar from 'react-native-material-design-searchbar';
//import SearchHeaderComponent from 'react-native-search-header';

import { Container, Content, List, ListItem, Item, Input, Left, Right, Body, Title, Button, Icon, Text, Header } from 'native-base';
import { Col, Row, Grid } from 'react-native-easy-grid';

import createFragment from 'react-addons-create-fragment'; // ES6

import { PROVIDER_GOOGLE, PROVIDER_DEFAULT } from 'react-native-maps';
const IOS = Platform.OS === 'ios';
const ANDROID = Platform.OS === 'android';

import EventListener from './components/Map/examples/EventListener';
import ServiceMarkers from './components/Map/ServiceMarkers';

const DEVICE_WIDTH = Dimensions.get(`window`).width;

import ForYou from './components/ForYou/ForYou';


import ServicesScreen from './components/ServiceGrid';
import FavouriteList from './components/Favourites/FavouriteList'
import { connect } from 'react-redux';

import * as PlaceSearchActionCreators from './reducers/PlaceSearchActionCreators';

import Hr from './hr.dist'
import Profile from './components/Profile/Profile'

import I18n from 'react-native-i18n'
console.disableYellowBox = true;
import NaviBar from './components/NaviBar'
//const SearchHeader = SearchHeaderComponent();
var {GooglePlacesAutocomplete} = require('react-native-google-places-autocomplete');

var Example = React.createClass({
  render() {
    return (
      <GooglePlacesAutocomplete
        placeholder='Search'
        minLength={2} // minimum length of text to search
        autoFocus={false}
        listViewDisplayed='true'    // auto/true/false/undefined
        fetchDetails={true}
        renderDescription={(row) => row.description} // custom description render
        onPress={(data, details = null) => { // 'details' is provided when fetchDetails = true
          console.log(data);
          console.log(details);
        }}
        getDefaultValue={() => {
          return ''; // text input default value
        }}
        query={{
          // available options: https://developers.google.com/places/web-service/autocomplete
          key: 'AIzaSyDTtyvfgtgYKNDfI1M7_D_VBeje6P4hkYM',
          language: 'en', // language of the results
          types: '(cities)', // default: 'geocode'
        }}
        styles={{
          description: {
            fontWeight: 'bold',
          },
          predefinedPlacesDescription: {
            color: '#1faadb',
          },
        }}

        currentLocation={true} // Will add a 'Current location' button at the top of the predefined places list
        currentLocationLabel="Current location"
        nearbyPlacesAPI='GooglePlacesSearch' // Which API to use: GoogleReverseGeocoding or GooglePlacesSearch
        GoogleReverseGeocodingQuery={{
          // available options for GoogleReverseGeocoding API : https://developers.google.com/maps/documentation/geocoding/intro
        }}
        GooglePlacesSearchQuery={{
          // available options for GooglePlacesSearch API : https://developers.google.com/places/web-service/search
          rankby: 'distance',
          types: 'food',
        }}


        filterReverseGeocodingByTypes={['locality', 'administrative_area_level_3']} // filter the reverse geocoding results by types - ['locality', 'administrative_area_level_3'] if you want to display only cities

      //  predefinedPlaces={[homePlace, workPlace]}

        debounce={200} // debounce the requests in ms. Set to 0 to remove debounce. By default 0ms.
      //  renderLeftButton={() => <Image source={require('path/custom/left-icon')} />}
        renderRightButton={() => <Text>Custom text after the inputg</Text>}
      />
    );
  }
});

const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        marginTop: 10
    },
    status: {
        zIndex: 10,
        elevation: 2,
        width: DEVICE_WIDTH,
        height: 21,
    },
  search: {
    flex: -1,
        width: DEVICE_WIDTH / 2,
    marginLeft: 5,
    borderRadius: 5,
  },
    header: {
      flex: 1,
        marginTop: 50,
        justifyContent: 'center',
        alignItems: 'center',
        width: DEVICE_WIDTH,
    },
    label: {
        flexGrow: 1,
        fontSize: 20,
        fontWeight: `600`,
        textAlign: `left`,
        marginVertical: 8,
        paddingVertical: 3,
        color: `#f5fcff`,
        backgroundColor: `transparent`
    },
    button: {
        flexGrow: 0,
        width: 70,
        height: 40,
        marginTop: 5,
        borderRadius: 2,
    },
  myHeader: {
    flex: 0,
    flexDirection: 'row',
            justifyContent: 'center',
        alignItems: 'center',
      marginTop: 15,
  },
  myOtherHeader: {
    flex: -1,
    zIndex: 1,
    minHeight:100,
  },
  suggestions: {
    flex: 0,
    height: 50,
    flexDirection: 'row',
    minHeight: 10,
    backgroundColor: '#00bcd4',
  },
  headerContainer: {
    flex: 1,
    flexShrink: 2,
  },
  currentHeader: {
    flex:0,
    flexDirection: 'row',
  },
    searchResults: {
      marginTop: 35,
      width: DEVICE_WIDTH /2,
    position: 'absolute',
    backgroundColor: 'white',
    borderColor: 'grey',
    borderWidth: 1,
    borderRadius: 10,
  },
  gridCol: {
    alignItems: 'center',
    paddingTop: 15,
    paddingBottom: 15,
    paddingLeft: 15,
  },
  gridItemImage: {
    height: 28,
    width: 28,
    marginBottom: 20,
  },
  gridColText: {
    fontSize: 14,
  },
  icon: {
    flex:1,
    width: 24,
    height: 24,
    resizeMode: 'contain'
  },
});

class SearchResults extends React.Component {
  render() {
    if (this.props.search.toUpperCase() !== 'BAM') {
      return null;
    }

    return (
      <View style={styles.searchResults}>
        <List>
          <FlatList
            data={[{key: 'a'}, {key: 'b'}]}
            renderItem={({item}) =>(
                <ListItem icon>
                <Body>
                <Text>Text</Text>
                </Body>
                <Right>
                      <Icon name='arrow-forward' />
                </Right>
                </ListItem>
            )}
          />
        </List>
      </View>
    );
  }
}

class MySearcbBox extends React.Component {
  render() {
    return (
      <View style={styles.search}>
        <TextInput
          style={{flex: -1, height: 30, borderColor: 'gray', borderWidth: 1}}
          value={this.props.search}
          onChangeText={this.props.onChange}
          placeholder="Try 'BAM'!"
        />
        <SearchResults search={this.props.search} />
      </View>
    );
  }
}

  class MyAppComponent extends React.Component {
      state = {
        currentSearch: ''
      };

      onCurrentSearchChange(text) {
        this.setState({
          currentSearch: text
        });
      }

      render() {
        return (
         <View style={styles.container}>
           <MySearcbBox search={this.state.currentSearch} onChange={this.onCurrentSearchChange.bind(this)} />
         </View>
        );
      }
    }

class MyHomeScreen extends React.Component {
  static navigationOptions = {
    tabBarLabel: 'Home',
  };

  render() {
    return (
      <Button
        onPress={() => this.props.navigation.navigate('Notifications')}
        title="Go to notifications"
      />
    );
  }
}

class MyNotificationsScreen extends React.Component {
  static navigationOptions = {
    tabBarLabel: 'Notifications',
  };

  render() {
    return (
      <Button
        onPress={() => this.props.navigation.goBack()}
        title="Go back home"
      />
    );
  }
}

class MapScreen extends React.Component {
  static navigationOptions = ({ navigation, screenProps }) => ({
    tabBarLabel:  I18n.t('main.tabs.map'),
  });
  render() {
    return(
      <ServiceMarkers />
    )
  }
}

const MainScreenNavigator = TabNavigator({
  Map: { screen: MapScreen },
  Services: { screen: ServicesScreen },
  ForYou: { screen: ForYou },
}, {

  navigationOptions: {
    drawerIcon: ({ tintColor }) => (
      <Image
        source={require('./assets/ic_menu_explore.png')}
        style={[styles.icon, {tintColor: tintColor}]}
      />
    ),
    title:I18n.t('hamburgerMenu.map'),
    header: (props) => createFragment({
        header: <NaviBar naviProps={props}/>
    })
  },
  tabBarComponent: TabBarTop,
  tabBarPosition: 'top',
  swipeEnabled: false,
  tabBarOptions: {
    indicatorStyle: {
      backgroundColor: '#F27242',
    },
    labelStyle: {
      fontFamily: 'Roboto',
      fontSize: 16,
    },
    tabStyle: {
    },
    style: {
      backgroundColor: '#335075',
      position: 'relative',
      top: 0,
      flex: -1,
      minHeight: 50,

    },
},
});




// Define our stack navigation
const MainDrawerNavigator = DrawerNavigator({
  Explore: {
    screen: MainScreenNavigator,
  },
  Favourites: {
    screen: FavouriteList,
  },
  Profile: {
    screen: Profile,
  }
},
{
  drawerWidth: 300,
  drawerPosition: 'left',
  contentOptions:{
    inactiveTintColor:'white',
    activeTintColor:'#F37242',
    activeBackgroundColor:'#2A4362',
    inactiveBackgroundColor:'#314F76',
    style: {
      backgroundColor: '#314F76',
    }
  },
}
)
const RootNavigator = StackNavigator({
  WalkThrough:{screen:WalkThrough},
  Home: { screen: MainDrawerNavigator },
  FilterModal: {screen:FilterModal},
},
{
  navigationOptions: {
    headerTintColor: 'white',
    headerStyle:{
      backgroundColor: '#314F76',
    }

  },
})

const store = configStore();
class ODGMobile extends React.Component {
  render(){
    return(
      <Provider store={ configStore() }>
      <RootNavigator />
      </Provider>
  );
  }
}

AppRegistry.registerComponent('ODGMobile', () => ODGMobile);
