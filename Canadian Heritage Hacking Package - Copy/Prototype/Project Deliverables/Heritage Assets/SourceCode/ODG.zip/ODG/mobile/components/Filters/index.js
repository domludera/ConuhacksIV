import React, { Component } from 'react'
import {
  Modal,
  View,
  Image,
  Switch,
  StatusBar,
  StyleSheet,
  TouchableHighlight,
  Dimensions
} from 'react-native'
import { connect } from 'react-redux';
import RadioForm, {RadioButton, RadioButtonInput, RadioButtonLabel} from 'react-native-simple-radio-button'
import { Container, Button, Content, Header, Title, List, ListItem, Text, Radio, Icon, Left, Right, Body} from 'native-base';
const { width, height } = Dimensions.get('window')
import * as FiltersActionCreators from '../../reducers/FiltersActionCreators'
import I18n from 'react-native-i18n'
const styles = StyleSheet.create({
    background: {
      backgroundColor:'#335075',
        color:'#335075'
    }});
class FilterModal extends Component {
  _onLanguageButtonPress (language)  {
    let { dispatch, filters } = this.props;
    filters.language = language;
    if (language === "en"){
      filters.provinceCode = "pr24";
    }else{
      filters.provinceCode = "!pr24";
    }
    let action = FiltersActionCreators.update(filters)
    dispatch(action);

  };
  _deleteSector(sector)  {

    let { dispatch, filters } = this.props;
    filters.sectors = filters.sectors.replace(";"+sector , "") ;
    filters.sectors = filters.sectors.replace(sector + ";", "") ;
    filters.sectors = filters.sectors.replace(sector, "") ;
    let action = FiltersActionCreators.update(filters)
    dispatch(action)
  };


  _addSector(sector)  {

    let { dispatch, filters } = this.props;
    filters.sectors += ";";
    filters.sectors += sector;
    var lastString = filters.sectors.substr(0, 1)
    if (lastString === ";"){
      filters.sectors = filters.sectors.substr(1, filters.sectors.length - 1)
    }
    let action = FiltersActionCreators.update(filters)
    dispatch(action)
  };
  _addAllFundedGroupSectors() {
    //"00 school;06 health and social services;
    this._addSector("06 health and social services");
    this._addSector("02 culture");
    this._addSector("01 community development")
    this._addSector("04 media and information technology")

  }
  _deleteAllFundedGroupSectors() {
    this._deleteSector("06 health and social services");
    this._deleteSector("02 culture");
    this._deleteSector("01 community development")
    this._deleteSector("04 media and information technology")
  }

  _deleteAllSchoolSectors() {
    this._deleteSector("00 IS");
    this._deleteSector("00 MS");
  }

  _addAllSchoolSectors() {
    //"00 school;06 health and social services;
    this._addSector("00 IS");
    this._addSector("00 MS");

  }
  getSectorsCount()  {

    let { filters } = this.props;
    var sectorsArray = filters.sectors.split(";").filter(function(word){
      return (word != "");
    })
    return  sectorsArray.length.toString();
  };
  constructor(props) {
    super(props);

    this.state = {
      modalVisible: false,
      filterEnglishSelected: true,
      filterFrenchSelected: false,
    };

  };
    state = {
      modalVisible: false,
      filterEnglishSelected: true,
      filterFrenchSelected: false,
    };
    _setModalVisible = (visible) => {
      this.setState({modalVisible: visible});
    };
    render() {
      const {language} = this.props
      var radio_props = [
        {label: "", value: 0 },
        {label: "", value: 1 }
      ];
      radio_props[0].label = I18n.t('intros.intro3EnglishButton', { locale: language });
      radio_props[1].label = I18n.t('intros.intro3FrenchButton', { locale: language });
      return (
    <View >
      <Modal

        animationType={"slide"}
        transparent={false}
        visible={this.state.modalVisible}
        onRequestClose={() => {alert("Modal has been closed.")}}
        >

       <Container style = {styles.background}>
       <Header style = {styles.background}>
       <Left>
                    <Title>{I18n.t('main.navibar.filters') + "(" + this.getSectorsCount() + ")"}</Title>
                     </Left>
                     <Right>
                    <Button onPress={this._setModalVisible.bind(this, false)} transparent>
                        <Icon  name="close" />
                    </Button>
                    </Right>

        </Header>
       <Content style = {styles.background}>
           <ListItem itemHeader first>
               <Text>{I18n.t('settings.language')}</Text>
           </ListItem>
           <ListItem>
               <RadioForm
                radio_props={radio_props}
                buttonColor={'#F27242'}
                initial={this.props.filters.language === "en" ? 0 : 1}
                onPress={(value) => {value == 0 ? this._onLanguageButtonPress("en") : this._onLanguageButtonPress("fr")}}
              />
           </ListItem>
           <ListItem>
             <Left>
                <Text>{I18n.t('services.allSchool', { locale: language })}</Text>
                </Left>
                <Right>
                <Switch
                  onTintColor="#F27242"
                  disabled={false}
                  style={{marginBottom: 10}}
                  onValueChange = {(value) => {
                    if (!value){
                      this._deleteAllSchoolSectors();
                    }else{
                      this._addAllSchoolSectors();
                  }}}
                  value={ this.props.filters.sectors.includes("00 IS")
                  && this.props.filters.sectors.includes("00 MS")} />
                  </Right>
             </ListItem>
           <ListItem>
                <Left>
                <Text>    {I18n.t('services.iSchool', { locale: language })}</Text>
                </Left>
                <Right>
                <Switch
                  disabled={false}
                  onTintColor="#F27242"
                  onValueChange = {(value) => {
                    (value) ? this._addSector("00 IS") : this._deleteSector("00 IS")
                  }}
                  style={{marginBottom: 10}}
                  value={this.props.filters.sectors.includes("00 IS")} />
                  </Right>
           </ListItem>
           <ListItem>
                <Left>
                <Text>    {I18n.t('services.mSchool', { locale: language })}</Text>
                </Left>
                <Right>
                <Switch
                  disabled={false}
                  onTintColor="#F27242"
                  onValueChange = {(value) => {
                    (value) ? this._addSector("00 MS") : this._deleteSector("00 MS")
                  }}
                  style={{marginBottom: 10}}
                  value={this.props.filters.sectors.includes("00 MS")} />
                  </Right>
           </ListItem>
           <ListItem>
             <Left>
                <Text>{I18n.t('services.allFundedGroup', { locale: language })}</Text>
                </Left>
                <Right>
                <Switch
                  onTintColor="#F27242"
                  disabled={false}
                  style={{marginBottom: 10}}
                  onValueChange = {(value) => {
                    if (!value){
                      this._deleteAllFundedGroupSectors();
                    }else{
                      this._addAllFundedGroupSectors();
                  }}}
                  value={ this.props.filters.sectors.includes("01 community development")
                  && this.props.filters.sectors.includes("04 media and information technology")
                  && this.props.filters.sectors.includes("06 health and social services")
                  && this.props.filters.sectors.includes("02 culture")} />
                  </Right>
             </ListItem>

           <ListItem>
                <Left>
                <Text>    {I18n.t('services.health', { locale: language })}</Text>
                </Left>
                <Right>
                <Switch
                  onTintColor="#F27242"
                  disabled={false}
                  onValueChange = {(value) => {
                    (value) ? this._addSector("06 health and social services") : this._deleteSector("06 health and social services")
                  }}
                  style={{marginBottom: 10}}
                  value={this.props.filters.sectors.includes("06 health and social services")} />
                  </Right>
           </ListItem>
           <ListItem>
                <Left>
                <Text>    {I18n.t('services.culture', { locale: language })}</Text>
                </Left>
                <Right>
                <Switch
                  onTintColor="#F27242"
                  disabled={false}
                  onValueChange = {(value) => {
                    (value) ? this._addSector("02 culture") : this._deleteSector("02 culture")
                  }}
                  style={{marginBottom: 10}}
                  value={this.props.filters.sectors.includes("02 culture")} />
                  </Right>
           </ListItem>
           <ListItem>
                <Left>
                <Text>    {I18n.t('services.community', { locale: language })}</Text>
                </Left>
                <Right>
                <Switch
                  onTintColor="#F27242"
                  disabled={false}
                  onValueChange = {(value) => {
                    (value) ? this._addSector("01 community development") : this._deleteSector("01 community development")
                  }}
                  style={{marginBottom: 10}}
                  value={this.props.filters.sectors.includes("01 community development")} />
                  </Right>
           </ListItem>
           <ListItem>
                <Left>
                <Text>    {I18n.t('services.media', { locale: language })}</Text>
                </Left>
                <Right>
                <Switch
                  onTintColor="#F27242"
                  disabled={false}
                  onValueChange = {(value) => {
                    (value) ? this._addSector("04 media and information technology") : this._deleteSector("04 media and information technology")
                  }}
                  style={{marginBottom: 10}}
                  value={this.props.filters.sectors.includes("04 media and information technology")} />
                  </Right>
           </ListItem>

       </Content>
            </Container>

      </Modal>
    </View>
  );
    }
}
const mapStateToProps = (state) => ({
    filters: state.Filters
  });

  export default connect(
      mapStateToProps,
      null,null,
      { withRef: true }
  )(FilterModal);
