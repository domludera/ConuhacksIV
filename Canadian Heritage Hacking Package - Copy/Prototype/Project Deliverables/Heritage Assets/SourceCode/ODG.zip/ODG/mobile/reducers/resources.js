import Resource from 'react-native-redux-rest-resource';

export default PostsResource = Resource(
    'services3',
    {
        API_URL: 'https://us-central1-heritagecanada-8a144.cloudfunctions.net/', // Define the URL of your API
    }
);
