export function update(filters) {
  return {
    type: 'UPDATE',
    filters
  }
}
