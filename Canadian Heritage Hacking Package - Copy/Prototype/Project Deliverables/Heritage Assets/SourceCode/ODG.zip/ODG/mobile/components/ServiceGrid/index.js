import React from 'react';
import {
  AppRegistry,
  TextInput,
  StyleSheet,
  Dimensions,
  StatusBar,
  View,
  Image,
  Platform,
  TouchableOpacity,
  FlatList
} from 'react-native';

import { Container, Content, List, ListItem, Item, Input, Left, Label, Right, Body, Title, Button, Text, Icon, Header } from 'native-base';
import { Col, Row, Grid } from 'react-native-easy-grid';

import { connect } from 'react-redux';
import * as FiltersActionCreators from '../../reducers/FiltersActionCreators'
import I18n from 'react-native-i18n'
import Hr from '../../hr.dist'

const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        marginTop: 10
    },
    gridCol: {
      alignItems: 'center',
      paddingTop: 15,
      paddingBottom: 15,
      paddingLeft: 10,
      marginTop: 15,
      height: 90,
    },
    eduItem: {
      alignItems: 'center',
      justifyContent: 'flex-start',
      paddingTop: 10,
      paddingBottom: 0,
      paddingLeft: 10,
      marginTop: -5,
      height: 90,
    },
    gridItemImage: {
      height: 35,
      width: 35,
      marginBottom: 20,
      flex:0,
      resizeMode: 'contain',
    },
    gridColText: {
      fontSize: 14,
      alignItems: 'center',
      justifyContent: 'center',
      flex: 1,
      flexWrap: 'wrap'
    },
    line: {
      backgroundColor: '#335075',
      marginTop: 5,
      marginHorizontal: 15,
      position: 'relative',
      top: 10
    },
    lineEdu: {
      backgroundColor: '#335075',
      marginTop: 5,
      marginHorizontal: 15,
      position: 'relative',
      top: 20
    },
    lineRow2: {
      backgroundColor: '#335075',
      marginTop: 0,
      marginHorizontal: 15,
      position: 'relative',
      top: -20,
      alignItems: 'flex-start',
    },
  });


class ServicesScreen extends React.Component {
  static navigationOptions = ({ navigation, screenProps }) => ({
    tabBarLabel: I18n.t('main.tabs.services'),
  });

  constructor(props) {
    super(props);
  }

  componentDidMount() {
    console.log("SERVICE GRID filters: ", this.props.filters)
  }

  _setSector(sector)  {
    let { dispatch, filters } = this.props;
    filters.sectors = sector;
    let action = FiltersActionCreators.update(filters)
    dispatch(action)
    this.props.navigation.navigate('Map', null);
  };

  // this._addSector("00 school");
  // this._addSector("06 health and social services");
  // this._addSector("02 culture");

  render() {
    console.log("SERVICE GRID filters: ", this.props.filters)
    console.log(this.props.navigation);

    return <Grid style={{backgroundColor: 'white'}}>
      <Row style={{flex: 0}}>

        <Col>
          <TouchableOpacity style={styles.gridCol} onPress={ () => {
            this._setSector("06 health and social services");
          }}
          >
            <Image
            style={styles.gridItemImage}
              source={require('../../assets/ic_health_social_services.png')}
            />
            <Text style={styles.gridColText}>{I18n.t('services.health')}</Text>
            </TouchableOpacity>
            <Hr lineStyle={styles.lineEdu}/>
        </Col>

        <Col >
          <TouchableOpacity style={{height: 150, justifyContent: 'center', alignItems: 'center'}} onPress={ () => {
            this._setSector("02 culture");
          }}
          >
          <Image
          style={styles.gridItemImage}
            source={require('../../assets/ic_culture_focus.png')}
          />
            <Text style={styles.gridColText}>{I18n.t('services.culture')}</Text>
            </TouchableOpacity>
            <Hr lineStyle={styles.lineRow2}/>
        </Col>

      </Row>

      <Row style={{flex: -1}}>
      <Col>
        <TouchableOpacity style={styles.eduItem} onPress={ () => {
          this._setSector("00 MS;00 IS");
        }}
        >
          <Image
          style={styles.gridItemImage}
            source={require('../../assets/ic_education.png')}
          />
          <Text style={styles.gridColText}>{I18n.t('services.school')}</Text>
        </TouchableOpacity>
        <Hr lineStyle={styles.lineEdu}/>
        </Col>

        <Col>
        <TouchableOpacity style={{height: 130, justifyContent: 'flex-start', alignItems: 'center'}} onPress={ () => {
        }}
        >
          <Image
          style={styles.gridItemImage}
            source={require('../../assets/ic_federal_services.png')}
          />
            <Text style={{justifyContent: 'center', flexWrap: 'wrap'}}>{I18n.t('services.federal')}</Text>
            <Text style={{justifyContent: 'center', flexWrap: 'wrap'}}>{I18n.t('services.fed2')}</Text>
        </TouchableOpacity>
        <Hr lineStyle={styles.lineRow2}/>
        </Col>
      </Row>
    </Grid>
  }
}

const mapStateToProps = (state) => ({
    filters: state.Filters,
});

export default connect(
    mapStateToProps,
)(ServicesScreen);
