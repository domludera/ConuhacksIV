export default  (
    state = {
        language: "en",
        provinceCode: "!pr24", //outside
        sectors:"",
    },
    action
) => {
        console.log(action);
    switch (action.type) {
      case "UPDATE":
        return {
            ...state,
            language:action.filters.language,
            provinceCode:action.filters.provinceCode,
            sectors:action.filters.sectors,
        };
      default:
          return state;
    }
  };
