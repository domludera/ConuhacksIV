export function update(searchResultData) {
  console.log("place search result update()");
  return {
    type: 'PLACE',
    searchResultData
  }
}

export function stopUntilNextSearch() {
  return {
    type: 'PLACE-STOP',
  }
}

export function doUpdateLabelViaReverseGeocodeLookup(formatted_address) {
  return {
    type: 'PLACE-REVERSE-GEO-LOOKUP',
    formatted_address
  }
}

export function setModalShouldClose(shouldClose) {
  return {
    type: 'PLACE-CLOSEMODAL',
    shouldClose
  }
}
