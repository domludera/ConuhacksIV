export default  (
    state = {
        searchResultData: 'none',
        placeSearchInvoked: false,
        modalShouldClose: false,
    },
    action
) => {
    switch (action.type) {
      case "PLACE":
      console.log("PlaceSearchReducer: Update")
      console.log(action)
        return {
            ...state,
            searchResultData: action.searchResultData,
            placeSearchInvoked: true,
            modalShouldClose: true,
        };

      case "PLACE-STOP":
      console.log("PlaceSearchReducer: STOP")
      return {
        ...state,
        placeSearchInvoked: false,
      };

      case "PLACE-CLOSEMODAL":
      console.log("PlaceSearchReducer: CLOSEMODAL");
      return {
        ...state,
        modalShouldClose: action.shouldClose,
      }

      case "PLACE-REVERSE-GEO-LOOKUP":

      default:
      console.log("Place Search Reducer doesn't recognize action type: "+ action.type);
          return state;
    }
  };
