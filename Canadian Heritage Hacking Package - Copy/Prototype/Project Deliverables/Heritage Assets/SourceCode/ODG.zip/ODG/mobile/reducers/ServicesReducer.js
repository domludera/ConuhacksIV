import ServicesResource from './resources';

export default  (
    state = {
      //the initial state
        List: {},
        loading: false,
        error: null,
    },
    action
) => {
        console.log(action)
    switch (action.type) {
        case 'SET-SELECTED':
          return {
            ...state,
            selected: action.service

          };
          case 'CLEAR-SELECTION':
          return {
            ...state,
            selected: null,
          };
        case 'SET-SLICE-INDEX':
        return {
          ...state,
          List: state.List.slice(action.index),
        }

        case ServicesResource.actions.CREATE:
        case ServicesResource.actions.READ:
        case ServicesResource.actions.UPDATE:
        case ServicesResource.actions.DELETE:
        case ServicesResource.actions.INDEX:
            return {
                ...state,
                loading: true,
            };
        case ServicesResource.actions.CREATE_SUCCESS:
        case ServicesResource.actions.READ_SUCCESS:
        case ServicesResource.actions.UPDATE_SUCCESS:
            return {
                ...state,
                List: {
                    ...action.payload.reduce((accumulator, service) => {
                        accumulator[service.name] = service;

                        return accumulator;
                    },
                    ...state.List,
                     {}),
                },
                loading: false,
                error: null,
            };
        case ServicesResource.actions.DELETE_SUCCESS:
            const updatedList = { ...state.List };

            delete updatedList[action.meta.id];

            return {
                ...state,
                List: updatedList,
                loading: false,
                error: null,
            };
        case ServicesResource.actions.INDEX_SUCCESS:
            return {
                ...state,
                List: {
                    ...state.List,
                    ...action.payload.reduce((accumulator, service) => {
                        accumulator[service.name] = service;
                        return accumulator;
                    }, {}),
                },
                loading: false,
                error: null,
            };
        case ServicesResource.actions.CREATE_FAILURE:
        case ServicesResource.actions.READ_FAILURE:
        case ServicesResource.actions.UPDATE_FAILURE:
        case ServicesResource.actions.DELETE_FAILURE:
        case ServicesResource.actions.INDEX_FAILURE:
            return {
                ...state,
                loading: false,
                error: action.payload,
            };
        default:
            return state;
    }
};
